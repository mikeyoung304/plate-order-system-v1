from .residents import router as residents_router
from .orders import router as orders_router
